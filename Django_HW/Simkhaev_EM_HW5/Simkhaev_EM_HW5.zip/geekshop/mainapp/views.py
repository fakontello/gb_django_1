from django.shortcuts import render, get_object_or_404
from mainapp.models import Product, ProductCategory

# Create your views here.
def index(request):
    context = {
        'page_title': 'главная',
    }
    return render(request, 'mainapp/index.html', context)


def products(request):
    categories = ProductCategory.objects.all()
    products = Product.objects.all()

    context = {
        'page_title': 'каталог',
        'categories': categories,
        'products': products,
    }
    return render(request, 'mainapp/products.html', context)


def category_products(request, pk):
    categories = ProductCategory.objects.all()
    if pk == '0':
        category = {'pk': 0, 'name': 'все'}
        products = Product.objects.all()
    else:
        category = get_object_or_404(ProductCategory, pk=pk)
        pass
        products = category.product_set.all()

    context = {
        'page_title': 'каталог',
        'categories': categories,
        'products': products,
        'category': category,
    }
    return render(request, 'mainapp/category_products.html', context)


def contact(request):
    locations = [
        {
            'city': 'Москва',
            'phone': '+7-495-888-8888',
            'email': 'info@geekshop.ru',
            'address': 'В пределах МКАД',
        },
        {
            'city': 'Санкт-Петербург',
            'phone': '+7-812-888-8888',
            'email': 'info@geekshop.ru',
            'address': 'В пределах КАД',
        },
        {
            'city': 'Владивосток',
            'phone': '+7-111-888-8888',
            'email': 'info@geekshop.ru',
            'address': 'В пределах города',
        },
    ]
    context = {
        'page_title': 'контакты',
        'locations': locations,
    }
    return render(request, 'mainapp/contact.html', context)
